/*
 *  /MathJax/fonts/HTML-CSS/TeX/png/Main/Bold/MiscMathSymbolsA.js
 *  
 *  Copyright (c) 2010-2013 The MathJax Consortium
 *
 *  Part of the MathJax library.
 *  See http://www.mathjax.org for details.
 * 
 *  Licensed under the Apache License, Version 2.0;
 *  you may not use this file except in compliance with the License.
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 */

MathJax.OutputJax["HTML-CSS"].defineImageData({"MathJax_Main-bold":{10216:[[3,8,2],[4,10,3],[4,11,3],[5,12,3],[6,15,4],[7,18,5],[8,20,5],[9,24,6],[11,28,7],[13,34,9],[15,40,10],[18,47,12],[22,56,14],[25,67,17]],10217:[[2,8,2],[3,10,3],[3,11,3],[4,12,3],[5,15,4],[6,18,5],[7,20,5],[8,24,6],[9,28,7],[11,34,9],[13,40,10],[15,47,12],[18,56,14],[21,67,17]]}});MathJax.Ajax.loadComplete(MathJax.OutputJax["HTML-CSS"].imgDir+"/Main/Bold"+MathJax.OutputJax["HTML-CSS"].imgPacked+"/MiscMathSymbolsA.js");

