<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class studentinfo extends Model
{
    protected $fillable = ['name','phone','score','precentage'];
}
