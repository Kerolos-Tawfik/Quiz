<?php

namespace App\Http\Controllers;

use App\Mail\coustmMail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class coustmMailController extends Controller
{
    public function sendMail(Request $request)
    {
        try {
            $request->validate([
                'email' => 'required|email',
                'percentage'=>'required'
            ]);
    


            Mail::to($request->email)->send(new coustmMail($request->percentage));
    
            return response()->json(['message' => 'تم']);
        } catch (\Throwable $e) {
            return response()->json([
                'message' => 'فشل في تنفيذ الطلب',
                'error' => $e->getMessage(),
            ], 500);
        }
    }
    
}
