<?php

namespace App\Http\Controllers;

use App\Models\Setting;
use Illuminate\Http\Request;

abstract class Controller
{
    // app/Http/Controllers/SettingController.php

}
